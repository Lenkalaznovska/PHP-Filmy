<!DOCTYPE html>
<html lang="cs-cz">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="icon" type="image/x-icon" href="img/favicon.png">
    
    <style>
        body {
            width: 20%;
            margin: auto;
            background-color: azure;
            margin-top: 20px;
            text-align: center;
        }
        
        .form {
            background-color: aquamarine;
            padding: 10px;
            margin-top: 20px;
            border: 1px solid black;
        }
        
        .vyhledat {
            background-color: white;
            margin: 10px;
            text-align: center;
        }
        
        table th, td, tr {
            width: 20%;
            border: 1px solid black;
        }  
    </style>
    
</head>

<body>
   
    <div class="form">
        <form action="" method="POST">
            <label for="nazevFilmu">Název filmu</label><br>
            <input type="text" name="nazevFilmu">
            <br>

            <label for="autor">Autor</label><br>
            <input type="text" name="autor">
            <br>
            
            <input class="vyhledat" type="submit" value="Vyhledat" name="Vyhledat">
            <input class="vyhledat" type="submit" value="Vložit" name="Vlozit">
            <input class="vyhledat" type="submit" value="Vrať se na seznam filmů" name="Vrať se na seznam filmů">
        </form>
    </div>
    
<?php
    include "conn.php";

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["Vlozit"])) {
        $nazevFilmu = mysqli_real_escape_string($conn, $_POST["nazevFilmu"]);
        $autor = mysqli_real_escape_string($conn, $_POST["autor"]);

        if (!empty($nazevFilmu) && !empty($autor)) {
            $sqlDuplicateCheck = "SELECT COUNT(*) as pocet FROM filmy WHERE `Název filmu` = '$nazevFilmu'";
            $duplicateResult = fetch($sqlDuplicateCheck, $conn);

            if ($duplicateResult >= 0) {
                echo "<p>Tento film již existuje v databázi s jiným autorem.</p>";
                echo "<p>Opravdu chcete aktualizovat existující záznam s novým autorem?</p>";
                echo '<form action="" method="POST">
                        <input type="hidden" name="confirmUpdate" value="true">
                        <input type="hidden" name="nazevFilmu" value="' . htmlspecialchars($nazevFilmu) . '">
                        <input type="hidden" name="autor" value="' . htmlspecialchars($autor) . '">
                        <input class="vyhledat" type="submit" value="Potvrdit aktualizaci" name="Potvrdit aktualizaci">
                      </form>';
            } else {
                $sql = "INSERT INTO filmy (`Název filmu`, `Autor`) 
                        VALUES ('$nazevFilmu', '$autor')";
                $vlozFilmy = akce($sql, $conn);
            }
        } else {
            echo "<p>Vyplňte všechna povinná pole.</p>";
        }
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["confirmUpdate"])) {
        $nazevFilmu = mysqli_real_escape_string($conn, $_POST["nazevFilmu"]);
        $newAutor = mysqli_real_escape_string($conn, $_POST["autor"]);

        $sql = "UPDATE filmy SET `Autor` = '$newAutor' WHERE `Název filmu` = '$nazevFilmu'";
        $updateFilmy = akce($sql, $conn);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["Vyhledat"])) {
        $nazevFilmu = $_POST["nazevFilmu"];
        $autor = $_POST["autor"];

        $nazevFilmu = mysqli_real_escape_string($conn, $nazevFilmu);
        $autor = mysqli_real_escape_string($conn, $autor);

        $sql = "SELECT * FROM filmy WHERE `Název filmu` LIKE '%$nazevFilmu%' AND `Autor` LIKE '%$autor%'";
        $filmy = fetchAll($sql, $conn);

        if (empty($filmy)) {
            echo "<p>Tento film není v databázi.</p>";
        } else {
            echo "<table>
                    <tr>
                        <th>Název filmu</th>
                        <th>Autor</th>
                    </tr>";

            foreach ($filmy as $f) {
                echo "<tr>
                        <td>" . $f["Název filmu"] . "</td>
                        <td>" . $f["Autor"] . "</td>
                    </tr>";
            }

            echo "</table>";
        }
    } else {
        
        $sql = "SELECT * FROM filmy";
        $filmy = fetchAll($sql, $conn);

        echo "<table>
                <tr>
                    <th>Název filmu</th>
                    <th>Autor</th>
                </tr>";

        foreach ($filmy as $f) {
            echo "<tr>
                    <td>" . $f["Název filmu"] . "</td>
                    <td>" . $f["Autor"] . "</td>
                </tr>";
        }

        echo "</table>";
    }
    ?>
</body>
</html>