<!DOCTYPE html>
<html lang="cs-cz">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="icon" type="image/x-icon" href="img/favicon.png">
    <link rel="stylesheet" href="css/style.css">
    
    <style>
        body {
            width: 20%;
            margin: auto;
            background-color: azure;
            margin-top: 20px;
            text-align: center;
        }
        
        .form {
            background-color: aquamarine;
            padding: 10px;
            margin-top: 20px;
        }
        
        .vyhledat {
            background-color: white;
            margin: 10px;
        }
        
        table td, tr {
            width: 20%;
        }
    </style>
</head>
<body>
    <div class="form">
        <form action="" method="POST">
            <label for="nazevFilmu">Název filmu</label><br>
            <input type="text" name="nazevFilmu">
            <br>

            <label for="autor">Autor</label><br>
            <input type="text" name="autor">
            <br>
            
            <input class="vyhledat" type="submit" value="Vyhledat" name="Vyhledat">
            <input class="vyhledat" type="submit" value="Vložit" name="Vlozit">
            </form>
    </div>
    
<?php
    include "conn.php";

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["Vlozit"])) {
        // Ochrana před SQL injection
        $nazevFilmu = mysqli_real_escape_string($conn, $_POST["nazevFilmu"]);
        $autor = mysqli_real_escape_string($conn, $_POST["autor"]);

        // Kontrola prázdných vstupů
        if (!empty($nazevFilmu) && !empty($autor)) {
            // Kontrola duplicity
            $sqlDuplicateCheck = "SELECT COUNT(*) as pocet FROM filmy WHERE `Název filmu` = '$nazevFilmu' AND `Autor` = '$autor'";
            $duplicateResult = fetch($sqlDuplicateCheck, $conn);

            if ($duplicateResult && isset($duplicateResult["pocet"]) && $duplicateResult["pocet"] == 0) {
                // Vložení do databáze
                $sql = "INSERT INTO filmy (`Název filmu`, `Autor`) 
                        VALUES ('$nazevFilmu', '$autor')";

                $vlozFilmy = akce($sql, $conn);
            } else {
                echo "<p>Tento film již existuje v databázi.</p>";
            }
        } else {
            echo "<p>Vyplňte všechna povinná pole.</p>";
        }
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["Vyhledat"])) {
        $nazevFilmu = $_POST["nazevFilmu"];
        $autor = $_POST["autor"];

        // Ochrana před SQL injection
        $nazevFilmu = mysqli_real_escape_string($conn, $nazevFilmu);
        $autor = mysqli_real_escape_string($conn, $autor);

        $sql = "SELECT * FROM filmy WHERE `Název filmu` LIKE '%$nazevFilmu%' AND `Autor` LIKE '%$autor%'";
        $filmy = fetchAll($sql, $conn);

        echo "<table>
                <tr>
                    <th>Název filmu</th>
                    <th>Autor</th>
                </tr>";

        foreach ($filmy as $f) {
            echo "<tr>
                    <td>" . $f["Název filmu"] . "</td>
                    <td>" . $f["Autor"] . "</td>
                </tr>";
        }

        echo "</table>";
    } else {
        
        $sql = "SELECT * FROM filmy";
        $filmy = fetchAll($sql, $conn);

        echo "<table>
                <tr>
                    <th>Název filmu</th>
                    <th>Autor</th>
                </tr>";

        foreach ($filmy as $f) {
            echo "<tr>
                    <td>" . $f["Název filmu"] . "</td>
                    <td>" . $f["Autor"] . "</td>
                </tr>";
        }

        echo "</table>";
    }
    ?>
</body>
</html>
