<!DOCTYPE html>
<html lang="cs-cz">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="icon" type="image/x-icon" href="img/favicon.png">
    <link rel="stylesheet" type="text/css" href="style.css">
    
    
</head>

<body>
   
    <div class="form">
        <form action="" method="POST">
            <label for="nazevFilmu">Název filmu</label><br>
            <input type="text" name="nazevFilmu">
            <br>

            <label for="autor">Autor</label><br>
            <input type="text" name="autor">
            <br>
            
            <input class="vyhledat" type="submit" value="Vyhledat" name="Vyhledat">
            <input class="vyhledat" type="submit" value="Vložit" name="Vlozit">
            <input class="zpet" type="submit" value="Zpět na výpis filmů" name="VratSeNaSeznamFilmu">
        </form>
    </div>
    
<?php
    include "conn.php";

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["Vlozit"])) {
        $nazevFilmu = $_POST["nazevFilmu"];
        $autor = $_POST["autor"];

        if (!empty($nazevFilmu) && !empty($autor)) {
            $stmt = $conn->prepare("INSERT INTO filmy (`Název filmu`, `Autor`) VALUES (?, ?)");
            $stmt->bind_param("ss", $nazevFilmu, $autor);
            $stmt->execute();
        } else {
            echo "<p>Vyplňte všechna povinná pole.</p>";
        }
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["Vyhledat"])) {
        $nazevFilmu = htmlspecialchars($_POST["nazevFilmu"]);
        $autor = htmlspecialchars($_POST["autor"]);

        $stmt = $conn->prepare("SELECT * FROM filmy WHERE `Název filmu` LIKE ? AND `Autor` LIKE ?");
        $nazevFilmuParam = "%$nazevFilmu%";
        $autorParam = "%$autor%";
        $stmt->bind_param("ss", $nazevFilmuParam, $autorParam);
        $stmt->execute();
        $result = $stmt->get_result();
        $filmy = $result->fetch_all(MYSQLI_ASSOC);

        if (empty($filmy)) {
            echo "<p>Tento film není v databázi.</p>";
        } else {    
            echo "<table>
                    <tr>
                        <th>Název filmu</th>
                        <th>Autor</th>
                    </tr>";

            foreach ($filmy as $f) {
                echo "<tr>
                        <td>" . htmlspecialchars($f["Název filmu"]) . "</td>
                        <td>" . htmlspecialchars($f["Autor"]) . "</td>
                    </tr>";
            }

            echo "</table>";
        }
    } else {
        $sql = "SELECT * FROM filmy";
        $filmy = fetchAll($sql, $conn);

        echo "<table>
                <tr>
                    <th>Název filmu</th>
                    <th>Autor</th>
                </tr>";

        foreach ($filmy as $f) {
            echo "<tr>
                    <td>" . htmlspecialchars($f["Název filmu"]) . "</td>
                    <td>" . htmlspecialchars($f["Autor"]) . "</td>
                </tr>";
        }

        echo "</table>";
    }
    ?>
</body>
</html>
